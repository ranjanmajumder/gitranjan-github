<template>
    <section>
        <base-card>
        <h1>{{fullName}}</h1>
        <h3>${{rate}}/hour</h3>
        </base-card>
    </section>
    <section>
        <base-card>
        <h1>Interested Reach Out Now!!!</h1>
            <div class="actions">
             <base-button link :to="coachContactLink">Contact</base-button>
         </div>
         <router-view></router-view>
        </base-card>
    </section>
    <section>
        <base-card>
         <div>
           <base-badge v-for="area in areas" :key="area" :type="area" :title="area">{{area}}</base-badge>
         </div>
         <p>{{description}}</p>
        </base-card>
    </section>
</template>

<script>

export default({
    props:['id'],
    data(){
        return{
            selectedForCoach:null,
        }
    },
    computed:{
        fullName(){
           return this.selectedForCoach.firstName+' '+this.selectedForCoach.lastName;
        },
        rate(){
            return this.selectedForCoach.hourlyRate;
        },
        coachContactLink(){
            return `${this.$route.path}/${this.id}/contact`
        },
        areas(){
            return this.selectedForCoach.areas;
        },
        description(){
            return this.selectedForCoach.description;
        }

    },
    created(){
        this.selectedForCoach=this.$store.getters['coaches/coaching'].find(coach=>coach.id===this.id)
    }
})
</script>
