export default{
    coaching(state){
        return state.coaches;
    },
    hascoaching(state){
        return state.coaches && state.coaches.length>0;
    },
    //isCoach(state,getters,rootstate,rootGetters)
    isCoach(state, _ ,_2 ,rootGetters){
        const coaches=state.coaches;
        //console.log(coaches);
        const userId=rootGetters.userId;
       // console.log(userId);
         return coaches.some(coach=>coach.id===userId);
    }
};