import { createRouter, createWebHistory } from 'vue-router';
import CoachDetail from './page/coaches/CoachDetail.vue'
import CoachesList from './page/coaches/CoachesList.vue'
import CoachRegistration from './page/coaches/CoachRegistration.vue'
import ContactCoach from './page/requests/ContactCoach.vue'
import RequestRecived from './page/requests/RequestRecived.vue'
import UserAuth from './page/auth/UserAuth.vue'
import NotFound from './page/NotFound.vue'

const router=createRouter({
    history:createWebHistory(),
    routes:[
        {path:'/',redirect:'/coaches'},
        {path:'/coaches',component:CoachesList},
        {path:'/coaches/:id',component:CoachDetail,props:true,
        children:[{
                path:'contact',component:ContactCoach
            }],
        },
        {path:'/register',component:CoachRegistration},
        {path:'/requests',component:RequestRecived},
        {path:'/auth',component:UserAuth},
        {path:'/:notFound(.*)',component:NotFound},
    ]
});

export default router;
