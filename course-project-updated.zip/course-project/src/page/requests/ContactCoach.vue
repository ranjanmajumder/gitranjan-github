<template>
    <form @submit.prevent="contactCoach">
        <div class="form-control" :class="{invalid:!email.isValid}">
            <label for="email" :class="{invalid:!email.isValid}">Email</label>
            <input type="email" name="email" id="email" v-model.trim="email.val" @blur="clearValidate('email')">
            <p v-if="!email.isValid">Email can not be blank</p>
        </div>
        <div class="form-control" :class="{invalid:!message.isValid}">
            <label for="message" :class="{invalid:!message.isValid}">Message</label>
            <textarea name="message" id="message" rows="5" v-model.trim="message.val" @blur="clearValidate('message')"></textarea>
            <p v-if="!message.isValid">Textarea can not be blank</p>
        </div>
        <div class="actions">
            <base-button>Send Message</base-button>
        </div>
    </form>
</template>

<script>

export default({
    data(){
        return{
            email:{
                val:'',
                isValid:true
            },
            message:{
                val:'',
                isValid:true,
            },
            isValidFrom:true,
        }
    },
    methods:{
        clearValidate(input){
            this[input].isValid=true;
      },
        validateData(){
            this.isValidFrom=true;
            if(this.email.val===""){
                this.email.isValid=false;
                this.isValidFrom=false;
            }
            if(this.message.val===""){
                this.message.isValid=false;
                this.isValidFrom=false;
            }
        },
        contactCoach(){
            this.validateData();
            console.log(this.message.isValid);
            if(!this.isValidFrom){
                return;
            }
            
            this.$store.dispatch('requests/contactCoach',{
                email:this.email.val,
                message:this.message.val,
                coachId:this.$route.params.id
            });
            this.$router.push('/coaches');
        }
    }
})
</script>


<style scoped>
form {
  margin: 1rem;
  border: 1px solid #ccc;
  border-radius: 12px;
  padding: 1rem;
}

.form-control {
  margin: 0.5rem 0;
}

label {
  font-weight: bold;
  margin-bottom: 0.5rem;
  display: block;
}

input,
textarea {
  display: block;
  width: 100%;
  font: inherit;
  border: 1px solid #ccc;
  border-radius:7px;
  padding: 0.25rem;
}

input:focus,
textarea:focus {
  border-color: #3d008d;
  background-color: #faf6ff;
  outline: none;
}

.errors {
  font-weight: bold;
  color: red;
}

.actions {
  text-align: center;
}
.invalid label, .invalid p {
  color: red;
}

.invalid input,
.invalid textarea {
  border: 1px solid red;
}
</style>