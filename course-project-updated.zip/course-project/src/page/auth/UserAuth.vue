<template>
<base-dialog :show="!!error" @close="hidePopup" title="An error Occured!!">{{error}}</base-dialog>
<base-card>
        <div v-if="isLoading">
            <base-spinner></base-spinner>
        </div>
    <form @submit.prevent="submitForm" v-else>
        
        <div class="form-control">
            <label type="email">Email</label>
            <input type="email" id="email" v-model="email" placeholder="Email..." autocomplete="true">
        </div>
        <div class="form-control">
            <label type="password">Password</label>
            <input type="password" id="password" placeholder="password" v-model.trim="password">
        </div>
        <p v-if="!isFormValid" :class="{invalid:!isFormValid}">Email or password is empty</p>
        <base-button >{{submitButtonText}}</base-button>
        <base-button type="button" mode="flat" @click="switchAuthMode">{{switchButtonText}}</base-button>        
    </form>
</base-card>
</template>
<script>
import BaseSpinner from '../../components/UI/BaseSpinner.vue';
export default{
  components: { BaseSpinner },
    data(){
        return{
            email:'',
            password:'',
            isFormValid:true,
            mode:'login',
            isLoading:false,
            error:null
        }
    },
    methods:{
        switchAuthMode(){
            if(this.mode==='login'){
                this.mode='SignUp';
            }
            else{
                this.mode='login';
            }
        },
        hidePopup(){
            this.error=null;
        },
        async submitForm(){
            
            if(this.email==='' || this.password.length<6){
                //console.log(this.email);
                this.isFormValid=false;
                return;
            }
            try
            {
                if(this.email!=='' || this.password.length>6){
                    this.isFormValid=true;
                }
                this.isLoading=true;
                    if(this.mode==='login'){
                    await this.$store.dispatch('login',{
                        email:this.email,
                        password:this.password
                    });
                }
                else{
                    await this.$store.dispatch('signUp',{
                        email:this.email,
                        password:this.password
                    });
                }
                this.isLoading=false;
                this.$router.push('/coaches')
                
            }
            catch(error){
                this.isLoading=true;
                this.error=error;
                this.isLoading=false;
            }

            
            
        }
    },
    computed:{
        submitButtonText(){
            if(this.mode==='login'){
                return 'Login';
            }
            else{
                return 'SignUp';
            }
        },
        switchButtonText(){
            if(this.mode==='login'){
                return 'SignUP';
            }
            else{
                return 'Login';
            }
        }
    }
}
</script>


<style scoped>
form {
  margin: 1rem;
  padding: 1rem;
}

.form-control {
  margin: 0.5rem 0;
}

label {
  font-weight: bold;
  margin-bottom: 0.5rem;
  display: block;
}

input,
textarea {
  display: block;
  width: 100%;
  font: inherit;
  border: 1px solid #ccc;
  padding: 0.25rem;
  border-radius:7px;
}

input:focus,
textarea:focus {
  border-color: #3d008d;
  background-color: #faf6ff;
  outline: none;
}
.invalid{
    color:red;
}
</style>
