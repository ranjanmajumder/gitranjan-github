export default{
    coaching(state){
        return state.coaches;
    },
    hascoaching(state){
        return state.coaches && state.coaches.length>0;
    },
    //isCoach(state,getters,rootstate,rootGetters)
    isCoach(_,getters,_2 ,rootGetters){
        const coaches=getters.coaching;
        //console.log(coaches);
        const userId=rootGetters.userId;
       // console.log(userId);
         return coaches.some(coach=>coach.id===userId);
    }
};