export default{
    async contactCoach(context,payload){
        const newReq={
            // id:new Date().toISOString(),
            coachId:payload.coachId,
            userEmail:payload.email,
            message:payload.message
        }
        //console.log(newReq);
        const response= await fetch(`https://coach-5ac74-default-rtdb.firebaseio.com/requests/${payload.coachId}.json`,{
            method:'POST',
            body:JSON.stringify(newReq)
        });

        const responseData=await response.json();

        if(!response.ok){
            const error=new Error(responseData.message || "Error in Request");
            throw error;
        }

        newReq.id=responseData.name;

        context.commit('addRequest',newReq);
    },

    async fetchRequest(context){
        const token=context.rootGetters.token;
        const coachId=context.rootGetters.userId;
        const response=await fetch(`https://coach-5ac74-default-rtdb.firebaseio.com/requests/${coachId}.json?auth=${token}`);
        const responseData=await response.json();
        if(!response.ok){
            const error=new Error(responseData.message || "Response error");
            throw error;
        }

        const requests=[];
        for(const key in responseData){
                const req={id:key,
                coachId:coachId,
                userEmail:responseData[key].userEmail,
                message:responseData[key].message,
            }
            requests.push(req);
        }
        context.commit('setRequests',requests);
    }
}