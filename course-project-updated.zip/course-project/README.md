Assignments:
1) If you try to sign up with same email id then it will show a dialog box(url:-http://localhost:8080/auth)
2)If you try to sign up with same email id then it will show the loader at first then it will show the dialog box(url:-http://localhost:8080/auth)
3)Each and every field of ContactCoach should be validated(url:-http://localhost:8080/coaches/TGiSpG1CWJSFkZMAwUyk44IE7Q33/contact), I have validated label and textbox also.
I have deployed the project in firebase(url:https://course-7439.web.app). This was the preliminary deployment. I deployed it at evening on dated 21-08-2021. 

The github project has slightly changes than the deployed project in firebase.

These are the assignments collected from the video of 18-08-2021 and rest of previous assignments was done by swapnil.
